import { useState, useMemo } from "react";
import { ArrowUpDown } from "lucide-react";
import CurrencySelect from "@/components/CurrencySelect";
import ConversionResult from "@/components/ConversionResult";
import SmartDecisionCard from "@/components/SmartDecisionCard";
import { convert, getExchangeRate, getSmartDecision } from "@/lib/currencies";

export default function Index() {
  const [amount, setAmount] = useState<string>("1000");
  const [fromCurrency, setFromCurrency] = useState("USD");
  const [toCurrency, setToCurrency] = useState("EUR");

  const numericAmount = useMemo(() => {
    const n = parseFloat(amount);
    return isNaN(n) ? 0 : n;
  }, [amount]);

  const result = useMemo(
    () => convert(numericAmount, fromCurrency, toCurrency),
    [numericAmount, fromCurrency, toCurrency]
  );

  const rate = useMemo(
    () => getExchangeRate(fromCurrency, toCurrency),
    [fromCurrency, toCurrency]
  );

  const decision = useMemo(
    () => getSmartDecision(fromCurrency, toCurrency),
    [fromCurrency, toCurrency]
  );

  const handleSwap = () => {
    setFromCurrency(toCurrency);
    setToCurrency(fromCurrency);
  };

  const now = new Date();
  const timeString = now.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });

  return (
    <div className="min-h-svh bg-background text-foreground flex items-center justify-center p-4">
      <div className="w-full max-w-[400px] space-y-6">
        {/* Header */}
        <header className="space-y-1 px-1">
          <h1 className="text-xs font-bold tracking-[0.2em] uppercase text-foreground/40">
            Nexus Change
          </h1>
          <p className="text-sm text-foreground/60">Precision Currency Utility</p>
        </header>

        {/* Main Card */}
        <div className="bg-card rounded-2xl p-6 shadow-[0_0_0_1px_rgba(255,255,255,0.05),0_20px_40px_-12px_rgba(0,0,0,0.5)] space-y-8">
          {/* Input Group */}
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-[10px] font-bold uppercase tracking-widest text-foreground/30 ml-1">
                Amount
              </label>
              <input
                type="number"
                inputMode="decimal"
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full h-14 bg-foreground/[0.03] rounded-lg px-4 text-xl font-medium tabular-nums text-foreground placeholder:text-foreground/20 focus:outline-none focus:ring-2 focus:ring-primary/40 transition-all"
              />
            </div>

            <div className="grid grid-cols-[1fr_40px_1fr] items-end gap-2">
              <CurrencySelect label="From" value={fromCurrency} onChange={setFromCurrency} />
              <button
                onClick={handleSwap}
                className="h-14 flex items-center justify-center hover:bg-foreground/5 rounded-lg transition-colors group active:scale-95"
                aria-label="Swap currencies"
              >
                <ArrowUpDown className="w-4 h-4 text-foreground/20 group-hover:text-foreground/60 transition-colors" />
              </button>
              <CurrencySelect label="To" value={toCurrency} onChange={setToCurrency} />
            </div>

            {/* Rate indicator */}
            <p className="text-xs text-foreground/30 text-center tabular-nums">
              1 {fromCurrency} = {rate.toFixed(4)} {toCurrency}
            </p>
          </div>

          {/* Result */}
          {numericAmount > 0 && (
            <ConversionResult amount={result} currencyCode={toCurrency} />
          )}

          {/* Smart Decision */}
          <SmartDecisionCard decision={decision} />
        </div>

        {/* Footer */}
        <footer className="px-1 flex justify-between items-center text-[10px] font-medium uppercase tracking-widest text-foreground/20">
          <span>Live Rates: {timeString}</span>
          <span>Source: ECB</span>
        </footer>
      </div>
    </div>
  );
}
