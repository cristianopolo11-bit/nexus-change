export interface Currency {
  code: string;
  name: string;
  symbol: string;
  flag: string;
}

export const currencies: Currency[] = [
  { code: "USD", name: "US Dollar", symbol: "$", flag: "🇺🇸" },
  { code: "EUR", name: "Euro", symbol: "€", flag: "🇪🇺" },
  { code: "AOA", name: "Angolan Kwanza", symbol: "Kz", flag: "🇦🇴" },
  { code: "GBP", name: "British Pound", symbol: "£", flag: "🇬🇧" },
  { code: "JPY", name: "Japanese Yen", symbol: "¥", flag: "🇯🇵" },
  { code: "CHF", name: "Swiss Franc", symbol: "Fr", flag: "🇨🇭" },
  { code: "CAD", name: "Canadian Dollar", symbol: "C$", flag: "🇨🇦" },
  { code: "AUD", name: "Australian Dollar", symbol: "A$", flag: "🇦🇺" },
  { code: "BRL", name: "Brazilian Real", symbol: "R$", flag: "🇧🇷" },
  { code: "CNY", name: "Chinese Yuan", symbol: "¥", flag: "🇨🇳" },
];

// Simulated exchange rates (base: USD)
const baseRates: Record<string, number> = {
  USD: 1,
  EUR: 0.92,
  AOA: 832.5,
  GBP: 0.79,
  JPY: 149.8,
  CHF: 0.88,
  CAD: 1.36,
  AUD: 1.53,
  BRL: 4.97,
  CNY: 7.24,
};

// Simulated 24h trend (percentage change)
const trends: Record<string, number> = {
  USD: 0,
  EUR: 0.3,
  AOA: -1.2,
  GBP: 0.8,
  JPY: -0.4,
  CHF: 0.1,
  CAD: -0.2,
  AUD: 0.6,
  BRL: -0.9,
  CNY: 0.2,
};

export function getExchangeRate(from: string, to: string): number {
  const fromRate = baseRates[from] ?? 1;
  const toRate = baseRates[to] ?? 1;
  return toRate / fromRate;
}

export function convert(amount: number, from: string, to: string): number {
  return amount * getExchangeRate(from, to);
}

export function getTrend(from: string, to: string): number {
  return (trends[to] ?? 0) - (trends[from] ?? 0);
}

export interface SmartDecision {
  label: string;
  sub: string;
  variant: "success" | "warning" | "neutral";
  icon: string;
}

export function getSmartDecision(from: string, to: string): SmartDecision {
  const trend = getTrend(from, to);
  if (trend > 0.5)
    return {
      label: "Good time to convert",
      sub: `The ${from} is currently performing stronger against the ${to} than the 7-day average.`,
      variant: "success",
      icon: "↑",
    };
  if (trend < -0.5)
    return {
      label: "Consider waiting",
      sub: `The rate is trending downward. You may get a better deal soon.`,
      variant: "warning",
      icon: "↓",
    };
  return {
    label: "Stable market",
    sub: "Minimal fluctuations detected. Safe to convert at your convenience.",
    variant: "neutral",
    icon: "→",
  };
}
